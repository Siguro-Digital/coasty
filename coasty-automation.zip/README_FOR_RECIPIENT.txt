═══════════════════════════════════════════════════════════════
  COASTY AUTOMATION - SUPER SIMPLE INSTRUCTIONS (Mac Only)
═══════════════════════════════════════════════════════════════

STEP 1: INSTALL NODE.JS (One Time)
   → Go to: https://nodejs.org/
   → Click the big green "Download" button
   → Install it and restart your computer

STEP 2: SETUP (One Time Only)
   → Double-click "Setup.command"
   → Wait for it to finish (2-5 minutes)
   → Done! ✅
   
   Note: PDFs are already included - no generation needed!

STEP 3: RUN THE PROGRAM (Every Time)
   → Double-click "Run.command"
   → Follow the on-screen menu

═══════════════════════════════════════════════════════════════

THAT'S IT! Just double-click the files!

If double-clicking doesn't work:
   → See QUICK_START.md for Terminal instructions

═══════════════════════════════════════════════════════════════

